from django.urls import path
from .views import home, game, final_score

urlpatterns = [
    path('', home, name='home'),
    path('game/', game, name='game'),
    path('final_score/', final_score, name='final_score'),
]
