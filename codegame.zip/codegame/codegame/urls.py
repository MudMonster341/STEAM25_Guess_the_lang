from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),  # Handles signup/login/logout
    path('', include('game.urls')),                # Home, game, final_score
]
